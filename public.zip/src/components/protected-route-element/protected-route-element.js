import { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { Navigate } from 'react-router-dom';

const ProtectedRouteElement = ({ element }) => {
  const [userLoaded, setUserLoaded] = useState(false);
  const { profileUserData } = useSelector((store) => store.profile);

  useEffect(() => {
    if (profileUserData) {
      setUserLoaded(true);
      console.log(userLoaded);
    }
  }, [profileUserData]);

  if (!userLoaded) {
    return <h1>Загрузка...</h1>;
  }

  return userLoaded ? element : <Navigate to={'/login'} replace />;
};

export default ProtectedRouteElement;
